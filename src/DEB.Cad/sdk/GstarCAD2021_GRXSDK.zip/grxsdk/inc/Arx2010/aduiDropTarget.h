#pragma once
#include "../grx/gduiDropTarget.h"

#define  UM_ADUI_DRAGENTER	 UM_GDUI_DRAGENTER	
#define  UM_ADUI_DRAGOVER	 UM_GDUI_DRAGOVER	
#define  UM_ADUI_DRAGLEAVE	 UM_GDUI_DRAGLEAVE	
#define  UM_ADUI_DROP		 UM_GDUI_DROP		
#define  UM_ADUI_DROPEX		 UM_GDUI_DROPEX		
#define  UM_ADUI_DRAGSCROLL	 UM_GDUI_DRAGSCROLL	 

#define  tagADUI_DRAGDATA  tagGDUI_DRAGDATA
#define  ADUI_DRAGDATA	   GDUI_DRAGDATA
#define  PADUI_DRAGDATA	   PGDUI_DRAGDATA

#define  CAdUiDropTarget   CGdUiDropTarget
